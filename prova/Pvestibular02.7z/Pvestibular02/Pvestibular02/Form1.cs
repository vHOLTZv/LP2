﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[2,5];

            string auxiliar = "";
            string auxiliar2 = "";

                for (int curso = 0; curso < 2; curso++)
                {
                auxiliar = Interaction.InputBox($"Digite o total do curso {curso+1}: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[curso, 0]))
                {
                    MessageBox.Show("Numero invalido");

                }
                listboxCursoeAno.Text = auxiliar;
                for (int ano = 0; ano < 5; ano++)
                {
                    auxiliar2 = Interaction.InputBox($"Digite o total do ano {ano + 1} no curso {curso + 1}: ", "Entrada de dados");
                    if (!int.TryParse(auxiliar2, out vetor[curso, ano]))
                    {
                        MessageBox.Show("Numero invalido");



                    }


                }

            }
            //matriz 2x5 de curso por ano
            //aluno por curso em cada ano
            //aluno curso
            //aluno total
            //entra é inteiro positivo apenas
            // LImpar é:  txtNumero1.Clear();

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listboxCursoeAno.Items.Clear();
        }
    }
    }
